# Gen Coin Wheel Bot

Ein Discord-Bot mit einem Coin-Wheel-System. User können Coins einsetzen, das Rad drehen und Coin-Gewinne oder Key-Rewards gewinnen. Staff kann Coins verwalten und Rewards erfüllen.

## Setup

### 1. Abhängigkeiten installieren
```bash
pip install -r requirements.txt
```

### 2. Umgebungsvariablen setzen

Der Bot liest Token und Guild ID aus Umgebungsvariablen (z.B. Railway, .env):

| Variable | Beschreibung |
|---|---|
| `TOKEN` | Dein Bot-Token vom Discord Developer Portal |
| `GUILD_ID` | Die ID deines Discord-Servers |

**Lokal mit .env:**
```
TOKEN=dein_token_hier
GUILD_ID=123456789012345678
```

### 3. Channel IDs anpassen (`bot.py`)

| Variable | Beschreibung |
|---|---|
| `WHEEL_PANEL_CHANNEL_ID` | Channel für das öffentliche Wheel-Panel |
| `WHEEL_LOG_CHANNEL_ID` | Channel für Logs |
| `WHEEL_STAFF_PANEL_CHANNEL_ID` | Channel für das Staff-Panel |
| `STAFF_ROLE_ID` | Rollen-ID des Staff-Teams |

### 4. Bot starten
```bash
python bot.py
```

### 5. Panels erstellen (im Discord)
- `/send_wheel_panel` — Öffentliches Wheel-Panel posten
- `/send_wheel_staff_panel` — Staff-Panel posten

## Features

- **Wheel Spins:** 3 Einsätze (5 / 10 / 25 Coins)
- **Rewards:** Coins, Key-Rewards (1 Day / 1 Week / Lifetime), Free Spin Credits
- **Balance:** Jeder User kann seinen Kontostand einsehen
- **Stats:** Statistiken pro User (Spins, gewonnene Coins, etc.)
- **Staff Panel:** Coins hinzufügen / entfernen / setzen, User prüfen, Key-Rewards erfüllen
- **Logs:** Alle Aktionen werden in den Log-Channel geloggt
- **Spin-Animation:** Animierte Wheel-Anzeige beim Drehen

## Hosting auf Railway

1. Neues Projekt auf [railway.app](https://railway.app) erstellen
2. GitHub-Repo verknüpfen
3. Unter **Variables** `TOKEN` und `GUILD_ID` eintragen
4. Deploy starten

## Voraussetzungen

- Python 3.10+
- Bot-Berechtigungen: `Send Messages`, `Read Message History`, `Embed Links`, `Manage Messages`
- Server Members Intent aktiviert im Developer Portal
